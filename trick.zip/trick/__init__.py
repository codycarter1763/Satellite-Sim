from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)
import sys
import os
sys.path.append(os.getcwd() + "/trick.zip/trick")

import _sim_services
from sim_services import *

# create "all_cvars" to hold all global/static vars
all_cvars = new_cvar_list()
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/NASA-Trick-Spacecraft-Docking-Simulation/S_source.hh
import _m5fbed1a8d3326af7b3f344b729ac903c
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/body_action/include/body_action.hh
import _m3e29bcf7e8c56a207374751c842ad711
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/body_action/include/class_declarations.hh
import _m3bce22edd5c5d55d4c8ac61a11a246a1
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/body_action/include/dyn_body_init.hh
import _mdd43286f03e8f7ee94e5bb646684dfbb
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/body_action/include/dyn_body_init_rot_state.hh
import _m5381ebc262a590b13409f765dc1dce5c
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/body_action/include/dyn_body_init_trans_state.hh
import _m0cd3869e0a56f8b9d38bc331b53e1240
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/body_action/include/mass_body_init.hh
import _m8ca4453b1253261184921b7fc26f305b
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/dyn_body/include/body_force_collect.hh
import _m9fc4109f984d0ef85ae1c3203c2fe5b9
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/dyn_body/include/body_ref_frame.hh
import _m4890991c1dc01e0d12fee5c8eca1f35d
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/dyn_body/include/class_declarations.hh
import _m8a99a4dda0dfab2a249f551173e087a8
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/dyn_body/include/dyn_body.hh
import _m1f3602c41c84b0662ed2fb583558b42e
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/dyn_body/include/dyn_body_generic_rigid_attach.hh
import _m8f048351aa3655643cef64437182940e
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/dyn_body/include/force.hh
import _m1560309b72558481f61be2ecf3370005
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/dyn_body/include/force_inline.hh
import _m28202e45f64ac5d18955a43b789c0080
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/dyn_body/include/frame_derivs.hh
import _mc26c34d0786e395a4ed4cc5c0df66ddc
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/dyn_body/include/torque.hh
import _m6e7c6365b8e60168a5b871ae8d108492
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/dyn_body/include/torque_inline.hh
import _mb1744ac345345e46ab25890d5a609874
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/dyn_manager/include/base_dyn_manager.hh
import _m5190b2ce45fc1c1a6d90a803095ea86b
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/dyn_manager/include/class_declarations.hh
import _m390301b16e5fa33a38bba8635183a943
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/dyn_manager/include/dyn_manager.hh
import _mef13429357b03f565fb810252204f92b
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/dyn_manager/include/dyn_manager_init.hh
import _m287a565c377a20b25d50e1ddea77f1a4
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/dyn_manager/include/dynamics_integration_group.hh
import _m6ebe970a94cbf8345df37cb23e46da26
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/mass/include/class_declarations.hh
import _m04df6c18dcbb2a87d753e692795e4b48
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/mass/include/mass.hh
import _mf62cb991d3afe225d5841898b834b3b0
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/mass/include/mass_body_links.hh
import _mec6fdbd8c3edf0cfde8bbc9c8be32c0f
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/mass/include/mass_messages.hh
import _m84f825defa14774c35e72e7bce28ac58
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/mass/include/mass_point.hh
import _m0d1d1d0907f61c1afb9498d4c3e06a6d
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/mass/include/mass_point_init.hh
import _m12c7d67b6475c9344bb88fb166c95e37
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/mass/include/mass_point_links.hh
import _mf82abb18f481e3e3322d37259a4602d8
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/mass/include/mass_point_state.hh
import _m90ec82817f945fe2064c37ed979159d6
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/mass/include/mass_properties.hh
import _m7d060d0b1a56bc8b2f03e2bc6e4aed57
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/dynamics/mass/include/mass_properties_init.hh
import _m11e8d580e1221c4ebf38d9c3a22b0392
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/ephemerides/ephem_interface/include/class_declarations.hh
import _m7f1f1a4b0efe7264a29a3a9b3914ea15
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/ephemerides/ephem_interface/include/ephem_interface.hh
import _me0e5e24071a13c28cc0b8a630dfe448b
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/ephemerides/ephem_interface/include/ephem_ref_frame.hh
import _m9db84639af422741d21ce4b6fa6a5fdc
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/ephemerides/ephem_interface/include/simple_ephemerides.hh
import _m27d26a86d423afe0b154431b3bc9e57b
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/ephemerides/ephem_item/include/class_declarations.hh
import _m460ab6072bbaf2e24cccd265f6324a4b
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/ephemerides/ephem_item/include/ephem_item.hh
import _md601f0febbc9b44787881eac591020bb
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/ephemerides/ephem_item/include/ephem_item_inline.hh
import _md6ae80ae0190a830b033b8de635364cb
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/ephemerides/ephem_item/include/ephem_point.hh
import _m5e35f71e4130bcf8a74bce7c4429b3e7
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/ephemerides/ephem_manager/include/base_ephem_manager.hh
import _m9f9574b333331ce4426bd3156ed2e19a
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/ephemerides/ephem_manager/include/ephem_manager.hh
import _mafc033b1c585e19428f80c36b5bbaedb
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/gravity/data/include/earth_spherical.hh
import _mcc1f2a16d19487085e949c744c820d3c
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/gravity/data/include/spherical_harmonics_gravity_source_default_data.hh
import _mc2fc36ed75d1c0d469e79c555271b1ac
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/gravity/include/class_declarations.hh
import _m41d3b42336202dc9110b02ecff15f149
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/gravity/include/gravity_controls.hh
import _m672f99445665897602dfe3ecd85a1d38
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/gravity/include/gravity_integ_frame.hh
import _m09b2dd4a891a701d77ca897913ff34bb
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/gravity/include/gravity_interaction.hh
import _m9119846dc948fe50bd4322ea5f38e76c
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/gravity/include/gravity_manager.hh
import _ma68bd6489eacfb6e6b10335dad4e0c82
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/gravity/include/gravity_source.hh
import _m4447fcab1a8ad4580a1d84929487f301
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/gravity/include/spherical_harmonics_delta_coeffs.hh
import _m9884fab2865e4e34174fb0b569f6ba73
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/gravity/include/spherical_harmonics_gravity_controls.hh
import _ma98d2f4c71ae2adc2da6fbe763862713
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/gravity/include/spherical_harmonics_gravity_source.hh
import _m12590552314ae81f26c61c19b2ffabe0
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/planet/data/include/earth.hh
import _m93766143eb3b9327c170a029f52acd0e
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/planet/data/include/planet_default_data.hh
import _m45e9307ed0d96f74a5477baff1547d2e
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/planet/include/base_planet.hh
import _m196e055cf46bb11cce03389fce6398f5
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/planet/include/class_declarations.hh
import _m154202a9d725df998ef9f18d64ade6c4
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/planet/include/planet.hh
import _m32f8ffa7f3c5bfb1f2b8fae3a39f9915
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/time/include/class_declarations.hh
import _mb964dcac3b5f0efd1f1b7620009a0885
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/time/include/time.hh
import _m9e0aba6dd538800fd5f7f0ffc7f12dc1
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/time/include/time_converter.hh
import _m760631200a0a27af912f43b71ae7ad50
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/time/include/time_dyn.hh
import _md71b1345648c28ff25fdcee1e762cb92
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/time/include/time_enum.hh
import _m7fedf3a6d2affcf09b5cfe9e88cb6107
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/time/include/time_links.hh
import _m8d90261fb1433bb49d5978e2fdfd0972
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/time/include/time_manager.hh
import _mc65c71a8cfab779d7e0fdbd5a135c309
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/environment/time/include/time_manager_init.hh
import _me793ff802618b767df635e5a687a3e18
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/container/include/checkpointable.hh
import _mbf9f8fcee5ee7713292e6171d312f6c2
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/container/include/container.hh
import _m621db96beb883aa1a3e3938e4c4cb68b
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/container/include/jeod_associative_container.hh
import _m0790c5a768460e37d17f16e4e8cd28ac
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/container/include/jeod_container_compare.hh
import _m104d72212c92ff22ed639998342ee87a
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/container/include/jeod_list.hh
import _m7ace65199351523b7b183b63b0d9fd10
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/container/include/jeod_sequence_container.hh
import _ma2813c9a2646ed01388fc05d3356c265
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/container/include/jeod_set.hh
import _mfaca1e46b725c27d849bf68ee0b7b8e0
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/container/include/jeod_stl_container.hh
import _mdafca6e6b06de3d1a24e547cad51ada9
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/container/include/jeod_vector.hh
import _mcb6a45583938e7dc19b225418cbc3a3c
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/container/include/pointer_container.hh
import _mc4252f2d891c163a81696088556b1d0b
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/container/include/pointer_list.hh
import _mecff64b838c14987bff4101112033ef7
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/container/include/pointer_vector.hh
import _m5786703422402442dc325702e7d00523
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/container/include/primitive_container.hh
import _m69cea09fd132726ae0e1350e0fbabae0
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/container/include/primitive_serializer.hh
import _m3ae7d4fe31be4af499ebaa995f8d9901
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/container/include/primitive_set.hh
import _mbe60e88d6c3d823b10a51e3c6e44acda
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/container/include/simple_checkpointable.hh
import _m425d5d3247e29bbce863f17c1220399e
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/integration/include/generalized_second_order_ode_technique.hh
import _m27e541fc569fe5d1fe1129a2394509fc
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/integration/include/integration_messages.hh
import _mce0f96e444db4252c958d1a09be5a8b7
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/integration/include/jeod_integration_group.hh
import _m8a49fdbf50cfeb648302b939121cf877
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/integration/include/jeod_integration_time.hh
import _m608ce8aa4a1e82c8e5c656b52c1e781a
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/integration/include/restartable_state_integrator.hh
import _m4d0b60f40f39486601477ce0a26832b0
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/integration/include/restartable_state_integrator_templates.hh
import _m8749c3abdfc69c487a37085b33804835
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/integration/include/time_change_subscriber.hh
import _m0638633ebc4c17d163a6c02c192141e9
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/math/include/macro_def.hh
import _m07f5a3d28ed5f420eab77e5c1c816e04
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/math/include/macro_undef.hh
import _me4999b0bda5e36aba8f35b255c51c3ed
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/math/include/matrix3x3.hh
import _mdb4a3b5372eadffbdf5bdeb60d13fbfa
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/math/include/matrix3x3_inline.hh
import _mec051240c6021d59097f4dca08209e04
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/math/include/numerical.hh
import _m861e0d000c58b747c87aa70dba45086e
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/math/include/numerical_inline.hh
import _m5c56dd67cc5008a260e40e1869b50da5
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/math/include/vector3.hh
import _m9e604849f06ca90394f3f3fd0494f03a
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/math/include/vector3_inline.hh
import _md00c2a50816dae27b32cb617818da8c4
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/memory/include/jeod_alloc.hh
import _mb05bbcbeef50d57a7a1bdb295e4f2a7b
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/memory/include/jeod_alloc_get_allocated_pointer.hh
import _m28c6116996ef259c042f5ba685ff4c43
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/memory/include/memory_manager.hh
import _mf750727138c103f6ae63d5aacdf9ef8c
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/message/include/class_declarations.hh
import _m705843a815ed6313f3acaf02c29e24c9
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/message/include/message_handler.hh
import _ma116cfc025cb0fb0f240a750c5ebd0f6
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/message/include/suppressed_code_message_handler.hh
import _mf5609617133215b6fb1c8c9a79468a93
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/named_item/include/named_item.hh
import _m99c52a01d0c1493d126b5daf3a533ced
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/orientation/include/orientation.hh
import _m9bc28b4469d4fbc3fad862d2604338d2
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/quaternion/include/quat.hh
import _m936105b3ecef3d82dc1228820e5976ac
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/quaternion/include/quat_inline.hh
import _m7ae53d98428ca0e9c8ec229bc1e6ab7a
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/ref_frames/include/base_ref_frame_manager.hh
import _m5c4812b2eda6b9e92b7412f276c7162c
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/ref_frames/include/class_declarations.hh
import _m83599a010eaad95a510ee967bbdf39dc
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/ref_frames/include/ref_frame.hh
import _m2fcfa5da38d90298d53bf3dac8006711
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_inline.hh
import _m7e7b8a4387dc233c093823f4620583ed
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_interface.hh
import _madd20e7cbbdb26b18195998e4519b0ba
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_items.hh
import _m35c63e3cf523b3bc698a2d2915601358
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_items_inline.hh
import _me81f42e7e2ee515905dbaa47bd5d4ade
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_links.hh
import _mcf4e9b49fcd1985f964136d0c4d1aa15
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_manager.hh
import _mc92c5d4de85a6e857864bd44c85a227f
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_messages.hh
import _m634db363c5db50f80e984c942e6948b4
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_state.hh
import _mcd9b69c703daac97f691981807f4cd3c
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_state_inline.hh
import _md21ac8bb32dd4d63d1d5c6dea5de14fb
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/ref_frames/include/subscription.hh
import _ma789fbea24734d99a3277679e7cd21fb
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/ref_frames/include/tree_links.hh
import _m78c7c558a03c8edde3c9084091a1d534
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/sim_interface/include/checkpoint_input_manager.hh
import _m611d76b1b8912b09165dcbae80e2f4af
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/sim_interface/include/checkpoint_output_manager.hh
import _ma14f779df731d5397012138ada25e42f
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/sim_interface/include/class_declarations.hh
import _m13982579c645f8ac705297439919519a
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/sim_interface/include/config.hh
import _m98b84751eb4ca77942b110cf70493322
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/sim_interface/include/config_trick10.hh
import _m08b085936a3e1a9019e0ee49ba4df8fa
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/sim_interface/include/jeod_class.hh
import _m6ad987e623c32ac62b4aeffd6094485b
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/sim_interface/include/jeod_integrator_interface.hh
import _m9f051a9b4973069bdb86fb0bb8771adf
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/sim_interface/include/jeod_trick_integrator.hh
import _mb87d3fbadafbb49b7d59d1fab22ca4b5
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/sim_interface/include/jeod_va_macro_utility.hh
import _m6886bbb4b11e344b98553a430420fb72
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/sim_interface/include/memory_attributes.hh
import _m74f750998e44fe0d65c5bffff2074d37
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/sim_interface/include/memory_interface.hh
import _mfcbbd6bbb2a4742ce35e4b40928b5557
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/sim_interface/include/simulation_interface.hh
import _m35ba81aa87cc5329246293526dd1626f
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/sim_interface/include/trick10_memory_interface.hh
import _me95f452ba3cde09fd11ce6a1bb3289fa
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/sim_interface/include/trick_memory_interface.hh
import _m2f06213f265462b4dbc53edebfb0ab4e
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/sim_interface/include/trick_message_handler.hh
import _m734a3884d0b0653af6c703ca3ca5ad38
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/jeod/models/utils/sim_interface/include/trick_sim_interface.hh
import _mfb5fbd14390fc55dc9d88a1b48e08caa
combine_cvars(all_cvars, cvar)
cvar = None

# /home/cody/NASA-Trick-Spacecraft-Docking-Simulation/S_source.hh
from m5fbed1a8d3326af7b3f344b729ac903c import *
# /home/cody/jeod/models/dynamics/body_action/include/body_action.hh
from m3e29bcf7e8c56a207374751c842ad711 import *
# /home/cody/jeod/models/dynamics/body_action/include/class_declarations.hh
from m3bce22edd5c5d55d4c8ac61a11a246a1 import *
# /home/cody/jeod/models/dynamics/body_action/include/dyn_body_init.hh
from mdd43286f03e8f7ee94e5bb646684dfbb import *
# /home/cody/jeod/models/dynamics/body_action/include/dyn_body_init_rot_state.hh
from m5381ebc262a590b13409f765dc1dce5c import *
# /home/cody/jeod/models/dynamics/body_action/include/dyn_body_init_trans_state.hh
from m0cd3869e0a56f8b9d38bc331b53e1240 import *
# /home/cody/jeod/models/dynamics/body_action/include/mass_body_init.hh
from m8ca4453b1253261184921b7fc26f305b import *
# /home/cody/jeod/models/dynamics/dyn_body/include/body_force_collect.hh
from m9fc4109f984d0ef85ae1c3203c2fe5b9 import *
# /home/cody/jeod/models/dynamics/dyn_body/include/body_ref_frame.hh
from m4890991c1dc01e0d12fee5c8eca1f35d import *
# /home/cody/jeod/models/dynamics/dyn_body/include/class_declarations.hh
from m8a99a4dda0dfab2a249f551173e087a8 import *
# /home/cody/jeod/models/dynamics/dyn_body/include/dyn_body.hh
from m1f3602c41c84b0662ed2fb583558b42e import *
# /home/cody/jeod/models/dynamics/dyn_body/include/dyn_body_generic_rigid_attach.hh
from m8f048351aa3655643cef64437182940e import *
# /home/cody/jeod/models/dynamics/dyn_body/include/force.hh
from m1560309b72558481f61be2ecf3370005 import *
# /home/cody/jeod/models/dynamics/dyn_body/include/force_inline.hh
from m28202e45f64ac5d18955a43b789c0080 import *
# /home/cody/jeod/models/dynamics/dyn_body/include/frame_derivs.hh
from mc26c34d0786e395a4ed4cc5c0df66ddc import *
# /home/cody/jeod/models/dynamics/dyn_body/include/torque.hh
from m6e7c6365b8e60168a5b871ae8d108492 import *
# /home/cody/jeod/models/dynamics/dyn_body/include/torque_inline.hh
from mb1744ac345345e46ab25890d5a609874 import *
# /home/cody/jeod/models/dynamics/dyn_manager/include/base_dyn_manager.hh
from m5190b2ce45fc1c1a6d90a803095ea86b import *
# /home/cody/jeod/models/dynamics/dyn_manager/include/class_declarations.hh
from m390301b16e5fa33a38bba8635183a943 import *
# /home/cody/jeod/models/dynamics/dyn_manager/include/dyn_manager.hh
from mef13429357b03f565fb810252204f92b import *
# /home/cody/jeod/models/dynamics/dyn_manager/include/dyn_manager_init.hh
from m287a565c377a20b25d50e1ddea77f1a4 import *
# /home/cody/jeod/models/dynamics/dyn_manager/include/dynamics_integration_group.hh
from m6ebe970a94cbf8345df37cb23e46da26 import *
# /home/cody/jeod/models/dynamics/mass/include/class_declarations.hh
from m04df6c18dcbb2a87d753e692795e4b48 import *
# /home/cody/jeod/models/dynamics/mass/include/mass.hh
from mf62cb991d3afe225d5841898b834b3b0 import *
# /home/cody/jeod/models/dynamics/mass/include/mass_body_links.hh
from mec6fdbd8c3edf0cfde8bbc9c8be32c0f import *
# /home/cody/jeod/models/dynamics/mass/include/mass_messages.hh
from m84f825defa14774c35e72e7bce28ac58 import *
# /home/cody/jeod/models/dynamics/mass/include/mass_point.hh
from m0d1d1d0907f61c1afb9498d4c3e06a6d import *
# /home/cody/jeod/models/dynamics/mass/include/mass_point_init.hh
from m12c7d67b6475c9344bb88fb166c95e37 import *
# /home/cody/jeod/models/dynamics/mass/include/mass_point_links.hh
from mf82abb18f481e3e3322d37259a4602d8 import *
# /home/cody/jeod/models/dynamics/mass/include/mass_point_state.hh
from m90ec82817f945fe2064c37ed979159d6 import *
# /home/cody/jeod/models/dynamics/mass/include/mass_properties.hh
from m7d060d0b1a56bc8b2f03e2bc6e4aed57 import *
# /home/cody/jeod/models/dynamics/mass/include/mass_properties_init.hh
from m11e8d580e1221c4ebf38d9c3a22b0392 import *
# /home/cody/jeod/models/environment/ephemerides/ephem_interface/include/class_declarations.hh
from m7f1f1a4b0efe7264a29a3a9b3914ea15 import *
# /home/cody/jeod/models/environment/ephemerides/ephem_interface/include/ephem_interface.hh
from me0e5e24071a13c28cc0b8a630dfe448b import *
# /home/cody/jeod/models/environment/ephemerides/ephem_interface/include/ephem_ref_frame.hh
from m9db84639af422741d21ce4b6fa6a5fdc import *
# /home/cody/jeod/models/environment/ephemerides/ephem_interface/include/simple_ephemerides.hh
from m27d26a86d423afe0b154431b3bc9e57b import *
# /home/cody/jeod/models/environment/ephemerides/ephem_item/include/class_declarations.hh
from m460ab6072bbaf2e24cccd265f6324a4b import *
# /home/cody/jeod/models/environment/ephemerides/ephem_item/include/ephem_item.hh
from md601f0febbc9b44787881eac591020bb import *
# /home/cody/jeod/models/environment/ephemerides/ephem_item/include/ephem_item_inline.hh
from md6ae80ae0190a830b033b8de635364cb import *
# /home/cody/jeod/models/environment/ephemerides/ephem_item/include/ephem_point.hh
from m5e35f71e4130bcf8a74bce7c4429b3e7 import *
# /home/cody/jeod/models/environment/ephemerides/ephem_manager/include/base_ephem_manager.hh
from m9f9574b333331ce4426bd3156ed2e19a import *
# /home/cody/jeod/models/environment/ephemerides/ephem_manager/include/ephem_manager.hh
from mafc033b1c585e19428f80c36b5bbaedb import *
# /home/cody/jeod/models/environment/gravity/data/include/earth_spherical.hh
from mcc1f2a16d19487085e949c744c820d3c import *
# /home/cody/jeod/models/environment/gravity/data/include/spherical_harmonics_gravity_source_default_data.hh
from mc2fc36ed75d1c0d469e79c555271b1ac import *
# /home/cody/jeod/models/environment/gravity/include/class_declarations.hh
from m41d3b42336202dc9110b02ecff15f149 import *
# /home/cody/jeod/models/environment/gravity/include/gravity_controls.hh
from m672f99445665897602dfe3ecd85a1d38 import *
# /home/cody/jeod/models/environment/gravity/include/gravity_integ_frame.hh
from m09b2dd4a891a701d77ca897913ff34bb import *
# /home/cody/jeod/models/environment/gravity/include/gravity_interaction.hh
from m9119846dc948fe50bd4322ea5f38e76c import *
# /home/cody/jeod/models/environment/gravity/include/gravity_manager.hh
from ma68bd6489eacfb6e6b10335dad4e0c82 import *
# /home/cody/jeod/models/environment/gravity/include/gravity_source.hh
from m4447fcab1a8ad4580a1d84929487f301 import *
# /home/cody/jeod/models/environment/gravity/include/spherical_harmonics_delta_coeffs.hh
from m9884fab2865e4e34174fb0b569f6ba73 import *
# /home/cody/jeod/models/environment/gravity/include/spherical_harmonics_gravity_controls.hh
from ma98d2f4c71ae2adc2da6fbe763862713 import *
# /home/cody/jeod/models/environment/gravity/include/spherical_harmonics_gravity_source.hh
from m12590552314ae81f26c61c19b2ffabe0 import *
# /home/cody/jeod/models/environment/planet/data/include/earth.hh
from m93766143eb3b9327c170a029f52acd0e import *
# /home/cody/jeod/models/environment/planet/data/include/planet_default_data.hh
from m45e9307ed0d96f74a5477baff1547d2e import *
# /home/cody/jeod/models/environment/planet/include/base_planet.hh
from m196e055cf46bb11cce03389fce6398f5 import *
# /home/cody/jeod/models/environment/planet/include/class_declarations.hh
from m154202a9d725df998ef9f18d64ade6c4 import *
# /home/cody/jeod/models/environment/planet/include/planet.hh
from m32f8ffa7f3c5bfb1f2b8fae3a39f9915 import *
# /home/cody/jeod/models/environment/time/include/class_declarations.hh
from mb964dcac3b5f0efd1f1b7620009a0885 import *
# /home/cody/jeod/models/environment/time/include/time.hh
from m9e0aba6dd538800fd5f7f0ffc7f12dc1 import *
# /home/cody/jeod/models/environment/time/include/time_converter.hh
from m760631200a0a27af912f43b71ae7ad50 import *
# /home/cody/jeod/models/environment/time/include/time_dyn.hh
from md71b1345648c28ff25fdcee1e762cb92 import *
# /home/cody/jeod/models/environment/time/include/time_enum.hh
from m7fedf3a6d2affcf09b5cfe9e88cb6107 import *
# /home/cody/jeod/models/environment/time/include/time_links.hh
from m8d90261fb1433bb49d5978e2fdfd0972 import *
# /home/cody/jeod/models/environment/time/include/time_manager.hh
from mc65c71a8cfab779d7e0fdbd5a135c309 import *
# /home/cody/jeod/models/environment/time/include/time_manager_init.hh
from me793ff802618b767df635e5a687a3e18 import *
# /home/cody/jeod/models/utils/container/include/checkpointable.hh
from mbf9f8fcee5ee7713292e6171d312f6c2 import *
# /home/cody/jeod/models/utils/container/include/container.hh
from m621db96beb883aa1a3e3938e4c4cb68b import *
# /home/cody/jeod/models/utils/container/include/jeod_associative_container.hh
from m0790c5a768460e37d17f16e4e8cd28ac import *
# /home/cody/jeod/models/utils/container/include/jeod_container_compare.hh
from m104d72212c92ff22ed639998342ee87a import *
# /home/cody/jeod/models/utils/container/include/jeod_list.hh
from m7ace65199351523b7b183b63b0d9fd10 import *
# /home/cody/jeod/models/utils/container/include/jeod_sequence_container.hh
from ma2813c9a2646ed01388fc05d3356c265 import *
# /home/cody/jeod/models/utils/container/include/jeod_set.hh
from mfaca1e46b725c27d849bf68ee0b7b8e0 import *
# /home/cody/jeod/models/utils/container/include/jeod_stl_container.hh
from mdafca6e6b06de3d1a24e547cad51ada9 import *
# /home/cody/jeod/models/utils/container/include/jeod_vector.hh
from mcb6a45583938e7dc19b225418cbc3a3c import *
# /home/cody/jeod/models/utils/container/include/pointer_container.hh
from mc4252f2d891c163a81696088556b1d0b import *
# /home/cody/jeod/models/utils/container/include/pointer_list.hh
from mecff64b838c14987bff4101112033ef7 import *
# /home/cody/jeod/models/utils/container/include/pointer_vector.hh
from m5786703422402442dc325702e7d00523 import *
# /home/cody/jeod/models/utils/container/include/primitive_container.hh
from m69cea09fd132726ae0e1350e0fbabae0 import *
# /home/cody/jeod/models/utils/container/include/primitive_serializer.hh
from m3ae7d4fe31be4af499ebaa995f8d9901 import *
# /home/cody/jeod/models/utils/container/include/primitive_set.hh
from mbe60e88d6c3d823b10a51e3c6e44acda import *
# /home/cody/jeod/models/utils/container/include/simple_checkpointable.hh
from m425d5d3247e29bbce863f17c1220399e import *
# /home/cody/jeod/models/utils/integration/include/generalized_second_order_ode_technique.hh
from m27e541fc569fe5d1fe1129a2394509fc import *
# /home/cody/jeod/models/utils/integration/include/integration_messages.hh
from mce0f96e444db4252c958d1a09be5a8b7 import *
# /home/cody/jeod/models/utils/integration/include/jeod_integration_group.hh
from m8a49fdbf50cfeb648302b939121cf877 import *
# /home/cody/jeod/models/utils/integration/include/jeod_integration_time.hh
from m608ce8aa4a1e82c8e5c656b52c1e781a import *
# /home/cody/jeod/models/utils/integration/include/restartable_state_integrator.hh
from m4d0b60f40f39486601477ce0a26832b0 import *
# /home/cody/jeod/models/utils/integration/include/restartable_state_integrator_templates.hh
from m8749c3abdfc69c487a37085b33804835 import *
# /home/cody/jeod/models/utils/integration/include/time_change_subscriber.hh
from m0638633ebc4c17d163a6c02c192141e9 import *
# /home/cody/jeod/models/utils/math/include/macro_def.hh
from m07f5a3d28ed5f420eab77e5c1c816e04 import *
# /home/cody/jeod/models/utils/math/include/macro_undef.hh
from me4999b0bda5e36aba8f35b255c51c3ed import *
# /home/cody/jeod/models/utils/math/include/matrix3x3.hh
from mdb4a3b5372eadffbdf5bdeb60d13fbfa import *
# /home/cody/jeod/models/utils/math/include/matrix3x3_inline.hh
from mec051240c6021d59097f4dca08209e04 import *
# /home/cody/jeod/models/utils/math/include/numerical.hh
from m861e0d000c58b747c87aa70dba45086e import *
# /home/cody/jeod/models/utils/math/include/numerical_inline.hh
from m5c56dd67cc5008a260e40e1869b50da5 import *
# /home/cody/jeod/models/utils/math/include/vector3.hh
from m9e604849f06ca90394f3f3fd0494f03a import *
# /home/cody/jeod/models/utils/math/include/vector3_inline.hh
from md00c2a50816dae27b32cb617818da8c4 import *
# /home/cody/jeod/models/utils/memory/include/jeod_alloc.hh
from mb05bbcbeef50d57a7a1bdb295e4f2a7b import *
# /home/cody/jeod/models/utils/memory/include/jeod_alloc_get_allocated_pointer.hh
from m28c6116996ef259c042f5ba685ff4c43 import *
# /home/cody/jeod/models/utils/memory/include/memory_manager.hh
from mf750727138c103f6ae63d5aacdf9ef8c import *
# /home/cody/jeod/models/utils/message/include/class_declarations.hh
from m705843a815ed6313f3acaf02c29e24c9 import *
# /home/cody/jeod/models/utils/message/include/message_handler.hh
from ma116cfc025cb0fb0f240a750c5ebd0f6 import *
# /home/cody/jeod/models/utils/message/include/suppressed_code_message_handler.hh
from mf5609617133215b6fb1c8c9a79468a93 import *
# /home/cody/jeod/models/utils/named_item/include/named_item.hh
from m99c52a01d0c1493d126b5daf3a533ced import *
# /home/cody/jeod/models/utils/orientation/include/orientation.hh
from m9bc28b4469d4fbc3fad862d2604338d2 import *
# /home/cody/jeod/models/utils/quaternion/include/quat.hh
from m936105b3ecef3d82dc1228820e5976ac import *
# /home/cody/jeod/models/utils/quaternion/include/quat_inline.hh
from m7ae53d98428ca0e9c8ec229bc1e6ab7a import *
# /home/cody/jeod/models/utils/ref_frames/include/base_ref_frame_manager.hh
from m5c4812b2eda6b9e92b7412f276c7162c import *
# /home/cody/jeod/models/utils/ref_frames/include/class_declarations.hh
from m83599a010eaad95a510ee967bbdf39dc import *
# /home/cody/jeod/models/utils/ref_frames/include/ref_frame.hh
from m2fcfa5da38d90298d53bf3dac8006711 import *
# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_inline.hh
from m7e7b8a4387dc233c093823f4620583ed import *
# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_interface.hh
from madd20e7cbbdb26b18195998e4519b0ba import *
# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_items.hh
from m35c63e3cf523b3bc698a2d2915601358 import *
# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_items_inline.hh
from me81f42e7e2ee515905dbaa47bd5d4ade import *
# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_links.hh
from mcf4e9b49fcd1985f964136d0c4d1aa15 import *
# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_manager.hh
from mc92c5d4de85a6e857864bd44c85a227f import *
# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_messages.hh
from m634db363c5db50f80e984c942e6948b4 import *
# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_state.hh
from mcd9b69c703daac97f691981807f4cd3c import *
# /home/cody/jeod/models/utils/ref_frames/include/ref_frame_state_inline.hh
from md21ac8bb32dd4d63d1d5c6dea5de14fb import *
# /home/cody/jeod/models/utils/ref_frames/include/subscription.hh
from ma789fbea24734d99a3277679e7cd21fb import *
# /home/cody/jeod/models/utils/ref_frames/include/tree_links.hh
from m78c7c558a03c8edde3c9084091a1d534 import *
# /home/cody/jeod/models/utils/sim_interface/include/checkpoint_input_manager.hh
from m611d76b1b8912b09165dcbae80e2f4af import *
# /home/cody/jeod/models/utils/sim_interface/include/checkpoint_output_manager.hh
from ma14f779df731d5397012138ada25e42f import *
# /home/cody/jeod/models/utils/sim_interface/include/class_declarations.hh
from m13982579c645f8ac705297439919519a import *
# /home/cody/jeod/models/utils/sim_interface/include/config.hh
from m98b84751eb4ca77942b110cf70493322 import *
# /home/cody/jeod/models/utils/sim_interface/include/config_trick10.hh
from m08b085936a3e1a9019e0ee49ba4df8fa import *
# /home/cody/jeod/models/utils/sim_interface/include/jeod_class.hh
from m6ad987e623c32ac62b4aeffd6094485b import *
# /home/cody/jeod/models/utils/sim_interface/include/jeod_integrator_interface.hh
from m9f051a9b4973069bdb86fb0bb8771adf import *
# /home/cody/jeod/models/utils/sim_interface/include/jeod_trick_integrator.hh
from mb87d3fbadafbb49b7d59d1fab22ca4b5 import *
# /home/cody/jeod/models/utils/sim_interface/include/jeod_va_macro_utility.hh
from m6886bbb4b11e344b98553a430420fb72 import *
# /home/cody/jeod/models/utils/sim_interface/include/memory_attributes.hh
from m74f750998e44fe0d65c5bffff2074d37 import *
# /home/cody/jeod/models/utils/sim_interface/include/memory_interface.hh
from mfcbbd6bbb2a4742ce35e4b40928b5557 import *
# /home/cody/jeod/models/utils/sim_interface/include/simulation_interface.hh
from m35ba81aa87cc5329246293526dd1626f import *
# /home/cody/jeod/models/utils/sim_interface/include/trick10_memory_interface.hh
from me95f452ba3cde09fd11ce6a1bb3289fa import *
# /home/cody/jeod/models/utils/sim_interface/include/trick_memory_interface.hh
from m2f06213f265462b4dbc53edebfb0ab4e import *
# /home/cody/jeod/models/utils/sim_interface/include/trick_message_handler.hh
from m734a3884d0b0653af6c703ca3ca5ad38 import *
# /home/cody/jeod/models/utils/sim_interface/include/trick_sim_interface.hh
from mfb5fbd14390fc55dc9d88a1b48e08caa import *

# S_source.hh
import _m5fbed1a8d3326af7b3f344b729ac903c
from m5fbed1a8d3326af7b3f344b729ac903c import *

import _top
import top

import _swig_double
import swig_double

import _swig_int
import swig_int

import _swig_ref
import swig_ref

from shortcuts import *

from exception import *

cvar = all_cvars

